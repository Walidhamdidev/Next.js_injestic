import React from "react";
function Index() {
    return (
        <div className="flex items-center justify-between w-full">
            <div className="w-full h-64 rounded shadow bg-white dark:bg-gray-800" />
        </div>
    );
}
export default Index;
