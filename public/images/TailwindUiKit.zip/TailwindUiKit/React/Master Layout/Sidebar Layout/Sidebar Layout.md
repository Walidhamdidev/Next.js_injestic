Sidebar Layouts provide an alternate master layout for your application. Sidebar layouts contain vertical navigation, header and a container to add more components.
